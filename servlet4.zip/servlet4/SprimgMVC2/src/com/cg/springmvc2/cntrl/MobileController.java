package com.cg.springmvc2.cntrl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.cg.springmvc2.dto.Mobile;
import com.cg.springmvc2.service.IMobileService;

@Controller
public class MobileController
{
	@Autowired
	IMobileService mobileservice;
	@RequestMapping(value="showall",method=RequestMethod.GET)
	
	public ModelAndView allMobileData()
	{
		List<Mobile>mobData=mobileservice.showAllMobiles();
		return new ModelAndView("mobileshow","temp",mobData);		
	}
	
	@RequestMapping(value="delete",method=RequestMethod.GET)
	public String mobileDelete(@RequestParam("id")int mobid)
	{
		System.out.println("Id is"+mobid);
		mobileservice.deleteMobile(mobid);
		return "redirect:/showall";
	}
	
	@RequestMapping(value="update",method=RequestMethod.GET)
	public String mobileUpdate(@RequestParam("id")int mobid,@RequestParam("name")String mobname,@RequestParam("price")Double moprice)
	{
		System.out.println("Id is"+mobid);
		System.out.println("Name is"+mobname);
		System.out.println("Price is"+moprice);
		mobileservice.updateMobile(mobid,mobname,moprice);
		return "redirect:/showall";
	}
}
