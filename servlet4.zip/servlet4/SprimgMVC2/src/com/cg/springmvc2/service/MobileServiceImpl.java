package com.cg.springmvc2.service;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.springmvc2.dao.IMobileDao;
import com.cg.springmvc2.dto.Mobile;

@Service("mobileservice")
@Transactional
public class MobileServiceImpl implements IMobileService
{
	@Autowired
	IMobileDao mobiledao;
	@Override
	public List<Mobile> showAllMobiles() 
	{
		return mobiledao.showAllMobiles();
	}

	@Override
	public void deleteMobile(int mobId) 
	{
		mobiledao.deleteMobile(mobId);
	}

	@Override
	public void updateMobile(int mobId,String mobName,Double mobPrice)
	{
		
		mobiledao.updateMobile(mobId,mobName,mobPrice);
	}

}
