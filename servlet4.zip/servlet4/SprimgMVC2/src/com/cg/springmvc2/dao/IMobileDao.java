package com.cg.springmvc2.dao;

import java.util.List;

import com.cg.springmvc2.dto.Mobile;

public interface IMobileDao
{
	public List<Mobile> showAllMobiles();
	public void deleteMobile(int mobId);
	public void updateMobile(int mobId,String mobName,Double mobPrice);
}
