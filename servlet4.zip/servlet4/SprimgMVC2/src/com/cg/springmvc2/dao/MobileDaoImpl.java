package com.cg.springmvc2.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;

import com.cg.springmvc2.dto.Mobile;

@Repository("mobiledao")
public class MobileDaoImpl implements IMobileDao
{
	@PersistenceContext
	EntityManager entitymanager;
	@Override
	public List<Mobile> showAllMobiles() 
	{
		Query query1=entitymanager.createQuery("FROM Mobile");
		List<Mobile> allData=query1.getResultList();
		return allData;
	}

	@Override
	public void deleteMobile(int mobId) 
	{
		Query query2=entitymanager.createQuery("DELETE FROM Mobile WHERE mobId=:id");
		query2.setParameter("id",mobId);
		query2.executeUpdate();
	}

	@Override
	public void updateMobile(int mobId,String mobName,Double mobPrice) 
	{
		Query query3=entitymanager.createQuery("UPDATE Mobile SET mobName=:name,mobPrice=:price, WHERE mobId=:id");
		query3.setParameter("name",mobName);
		query3.setParameter("price",mobPrice);
		query3.setParameter("id",mobId);
		query3.executeUpdate();
	}

}
