package com.cg.controller;

import java.io.IOException;
import java.sql.Date;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.cg.dto.Mobile;
import com.cg.dto.Purchases;
import com.cg.exception.MobileException;
import com.cg.service.IMobServiceImpl;
import com.cg.service.MobService;

@WebServlet(urlPatterns={"/home","/buy","/Purchase","/update"})
public class PurchaseController extends HttpServlet {
	private static final long serialVersionUID = 1L;


	public PurchaseController() 
	{
		super();

	}


	public void init(ServletConfig config) throws ServletException
	{

	}

	public void destroy() 
	{

	}
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException 
	{
		doPost(request,response);
	}
	protected void doPost(HttpServletRequest request, HttpServletResponse response) 
			throws ServletException, IOException
	{
		String url=request.getServletPath();
		String targetUrl=" ";
		MobService mSer=new IMobServiceImpl();
		switch(url)
		{
		case "/home":

			try 
			{
				List<Mobile>mobList=mSer.getAllMobiles();
				request.setAttribute("mobList", mobList);
				targetUrl="Home.jsp";
			} 
			catch (MobileException e)
			{
				request.setAttribute("error", e.getMessage());
				targetUrl="Error.jsp";
			}
			break;	
								/****************/
		case "/buy":
			
			Long mid=Long.parseLong(request.getParameter("mid"));
			try
			{
				Mobile mob=mSer.getMobile(mid);
				HttpSession session=request.getSession(true);
				session.setAttribute("mob", mob);
				targetUrl="Insert.jsp";
				
			} 
			catch (MobileException e) 
			{
				request.setAttribute("error", e.getMessage());
				targetUrl="Error.jsp";
			}
			break;
			
		case "/Purchase":	
			
			Purchases pd=new Purchases();
			pd.setCustname(request.getParameter("cname"));
			pd.setMailid(request.getParameter("mail"));
			pd.setPhoneno(Long.parseLong(request.getParameter("phoneno")));
			String dateStr=request.getParameter("pdate");
			DateTimeFormatter format=DateTimeFormatter.ofPattern("yyyy-MM-dd");
			pd.setPurchaseDate(LocalDate.parse(dateStr,format));
			HttpSession session=request.getSession(false);
			Mobile mob=(Mobile)session.getAttribute("mob");
			pd.setMobileid(mob.getMobileid());
			try
			{
				mSer.insertPurchaseDetails(pd);
				request.setAttribute("pdetails", pd);
				targetUrl="Success.jsp";			
			}
			catch(MobileException e)
			{
				request.setAttribute("error", e.getMessage());
				targetUrl="Error.jsp";
			}
		
		case "/update":
			
			Long mid1=Long.parseLong(request.getParameter("mid"));
			try
			{
				int update=mSer.updateMobile(mid1);
				targetUrl="home.jsp";
				
			} 
			catch (MobileException e) 
			{
				request.setAttribute("error", e.getMessage());
				targetUrl="Error.jsp";
			}
			break;
		}
		RequestDispatcher rd=request.getRequestDispatcher(targetUrl);
		rd.forward(request, response);
	}
}
