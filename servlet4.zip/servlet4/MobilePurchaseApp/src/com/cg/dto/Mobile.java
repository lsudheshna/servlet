package com.cg.dto;

public class Mobile
{
	private long mobileid;
	private String mobName;
	private double mobPrice;
	private int mobQunatity;
	
	public Mobile() 
	{
		super();
	}
	
	public Mobile(long mobileid, String mobName, double mobPrice,
			int mobQunatity)
	{
		super();
		this.mobileid = mobileid;
		this.mobName = mobName;
		this.mobPrice = mobPrice;
		this.mobQunatity = mobQunatity;
	}
	
	public long getMobileid()
	{
		return mobileid;
	}
	public void setMobileid(long mobileid)
	{
		this.mobileid = mobileid;
	}
	public String getMobName() 
	{
		return mobName;
	}
	public void setMobName(String mobName)
	{
		this.mobName = mobName;
	}
	public double getMobPrice() 
	{
		return mobPrice;
	}
	public void setMobPrice(double mobPrice)
	{
		this.mobPrice = mobPrice;
	}
	public int getMobQunatity() 
	{
		return mobQunatity;
	}
	public void setMobQunatity(int mobQunatity)
	{
		this.mobQunatity = mobQunatity;
	}
	@Override
	public String toString() {
		return "Mobile [mobileid=" + mobileid + ", mobName=" + mobName
				+ ", mobPrice=" + mobPrice + ", mobQunatity=" + mobQunatity
				+ "]";
	}
	
	
}
