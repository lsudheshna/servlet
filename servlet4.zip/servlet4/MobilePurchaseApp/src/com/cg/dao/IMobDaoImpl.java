package com.cg.dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.cg.dto.Mobile;
import com.cg.dto.Purchases;
import com.cg.exception.MobileException;
import com.cg.util.DBUtil;

public class IMobDaoImpl implements MobDao
{
	Connection con=null;
	Statement stmt=null;
	PreparedStatement pst=null;
	ResultSet rs=null;

	@Override
	public long insertPurchaseDetails(Purchases pd) throws MobileException 
	{
		pd.setPid(generatePurchaseId());
		try 
		{
			con=DBUtil.getCon();
			pst=con.prepareStatement(QueryMapper.insertQry);
			pst.setLong(1,pd.getPid());
			pst.setString(2,pd.getCustname());
			pst.setString(3,pd.getMailid());
			pst.setLong(4,pd.getPhoneno());
			pst.setDate(5,Date.valueOf(pd.getPurchaseDate()));
			pst.setLong(6,pd.getMobileid());
			pst.executeUpdate();
		}
		catch (SQLException e)
		{
			throw new MobileException("Problem in inserting mobile details"+e.getMessage());

		}
		return pd.getPid();
	}

	private long generatePurchaseId() throws MobileException 
	{
		long pid=0;
		try 
		{
			con=DBUtil.getCon();
			stmt=con.createStatement();
			rs=stmt.executeQuery(QueryMapper.selectsequence);
			rs.next();
			pid=rs.getLong(1);

		}
		catch (Exception e) 
		{
			throw new MobileException("Problem in generating sequence"+e.getMessage());
		}
		return pid;
	}

	@Override
	public List<Mobile> getAllMobiles() throws MobileException
	{
		List<Mobile> mobList=new ArrayList<Mobile>();
		Mobile mb=null;
		con=DBUtil.getCon();
		try 
		{

			stmt=con.createStatement();
			rs=stmt.executeQuery(QueryMapper.selectAllQry);
			while(rs.next())
			{
				mb=new Mobile();
				mb.setMobileid(rs.getLong("mobileid"));
				mb.setMobName(rs.getString("name"));
				mb.setMobPrice(rs.getDouble("price"));
				mb.setMobQunatity(rs.getInt("quantity"));
				mobList.add(mb);
			}

		}
		catch (Exception e)
		{

			throw new MobileException("Problem in fetching mobiles"+e.getMessage());

		} 
		finally
		{
			try
			{
				rs.close();
				stmt.close();
				con.close();
			} 
			catch (SQLException e)
			{
				throw new MobileException(e.getMessage());
			}

		}
		return mobList;
	}

	@Override
	public Mobile getMobile(long mid) throws MobileException 
	{
		Mobile mb=null;
		con=DBUtil.getCon();
		try 
		{
			pst=con.prepareStatement(QueryMapper.selectQry);
			pst.setLong(1, mid);
			rs=pst.executeQuery();;
			if(rs.next())
			{
				mb=new Mobile();
				mb.setMobileid(rs.getLong("mobileId"));
				mb.setMobName(rs.getString("name"));
				mb.setMobPrice(rs.getDouble("price"));
				mb.setMobQunatity(rs.getInt("quantity"));
			}
			else
			{
				throw new MobileException("Mobile not found");
			}

		}
		catch (SQLException e)
		{

			throw new MobileException("Problem in fetching mobiles"+e.getMessage());

		} 
		return mb;
	}

	public int updateMobile(long mid)throws MobileException
	{
		int dataupdated=0;
		try 
		{
			con=DBUtil.getCon();
			pst=con.prepareStatement(QueryMapper.updateQry);
			dataupdated=pst.executeUpdate();
		}
		catch (Exception e)
		{

			throw new MobileException("Problem in updating mobiles"+e.getMessage());

		} 
		return dataupdated;
	}
}
