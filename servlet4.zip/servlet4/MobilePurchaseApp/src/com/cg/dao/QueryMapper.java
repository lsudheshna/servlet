package com.cg.dao;

public interface QueryMapper
{

	String insertQry="insert into PurchaseDetails(purchaseid,cname,mailid,phoneno,purchasedate,mobileid) values(?,?,?,?,?,?)";
	String selectQry="SELECT * from mobiles where mobileid=?";
	String selectAllQry="SELECT * from mobiles ";
	String selectsequence="SELECT purchase_seq.NEXTVAL FROM DUAL";
	String updateQry="update mobiles quantity=quantity-1 where mobileid=?";
}
