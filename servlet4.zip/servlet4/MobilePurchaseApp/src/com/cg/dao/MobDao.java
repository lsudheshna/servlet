package com.cg.dao;

import java.util.List;
import com.cg.dto.Mobile;
import com.cg.dto.Purchases;
import com.cg.exception.MobileException;

public interface MobDao
{
	public long insertPurchaseDetails(Purchases pd) throws MobileException;
	
	List<Mobile> getAllMobiles() throws MobileException;
	
	Mobile getMobile(long mid)throws MobileException;
	
	public int updateMobile(long mid)throws MobileException;
}
