package com.cg.service;

import java.util.List;
import com.cg.dao.IMobDaoImpl;
import com.cg.dao.MobDao;
import com.cg.dto.Mobile;
import com.cg.dto.Purchases;
import com.cg.exception.MobileException;

public class IMobServiceImpl implements MobService
{
	MobDao mobDao=null;
	
	public IMobServiceImpl()
	{
		super();
		mobDao=new IMobDaoImpl();
	}

	@Override
	public long insertPurchaseDetails(Purchases pd) throws MobileException
	{
		
		return mobDao.insertPurchaseDetails(pd);
	}

	@Override
	public List<Mobile> getAllMobiles() throws MobileException
	{
		
		return mobDao.getAllMobiles();
	}

	@Override
	public Mobile getMobile(long mid) throws MobileException 
	{
		
		return mobDao.getMobile(mid);
	}
	public int updateMobile(long mid)throws MobileException
	{

		return mobDao.updateMobile(mid);
	}
}
