package com.cg.user.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.cg.user.dto.*;
import com.cg.user.exception.LoginException;
import com.cg.user.util.DBUtil;

public class LoginDaoImpl implements LoginDao
{
	Connection con=null;
	PreparedStatement pst=null;
	ResultSet rs=null;
	Login user=null;
	
	@Override
	public Login getUserByUnm(String unm) throws LoginException
	{
		try
		{
		con=DBUtil.getCon();
		System.out.println("Got Connection");
		String qry="select * from user_142546 where user_id=?";
		pst=con.prepareStatement(qry);
		pst.setString(1, unm);
		rs=pst.executeQuery();
		rs.next();
		user=new Login(rs.getString("user_id"),rs.getString("password"));
		}
		catch(Exception e)
		{
			throw new LoginException(e.getMessage());
		}
		
		return user;
	}
}
