package com.cg.user.ctrl;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.cg.service.*;
import com.cg.user.dto.*;


@WebServlet("/LoginController")
public class LoginController extends HttpServlet
{
	private static final long serialVersionUID = 1L;
	ServletConfig cg=null;
	LoginService logSer=null;
	public LoginController() {
		super();

	}


	public void init(ServletConfig config) throws ServletException {

	}

	public void destroy() {

	}


	protected void doGet(HttpServletRequest request, HttpServletResponse response) 
			throws ServletException, IOException
	{
		doPost(request,response);
	}


	protected void doPost(HttpServletRequest request, HttpServletResponse response) 
			throws ServletException, IOException 
	{
		HttpSession session=request.getSession(true);
		logSer = new LoginServiceImpl();
		String action=request.getParameter("action");
		RequestDispatcher rd=null;
		if(action!=null)
		{
			try
			{
				/************ShowWelcomePage*************/
				if(action.equals("ShowWelcomePage"))//showwelcomepage action is what user has requested in home.jsp page
				{
					//controller forwards to welcome page if action is same as what user has requested else it sends to error page
					rd=request.getRequestDispatcher("Pages/Welcome.jsp");
					rd.forward(request, response);
				}
				/***********EndShowWelcomePage*****/
			
				/**********ShowLoginPage*************/
				if(action.equals("ShowLoginPage"))
				{
					rd=request.getRequestDispatcher("Pages/Login.jsp");
					rd.forward(request, response);
				}
				/************EndLoginPage*************/
				
				/**********ShowSuccessPage*************/
				if(action.equals("ShowSuccessPage"))
				{
					String unm=request.getParameter("txtname");
					String pwd=request.getParameter("pwdname");
					Login user=logSer.getUserByUnm(unm);
					//compares database usrname and pwd with user entry usrname and pwd
					if ( (user.getUserName().equals(unm)) && (user.getPassword().equals(pwd)) )
					{
						session.setAttribute("userNameObj", unm);
						rd=request.getRequestDispatcher("/SuccessPage");
						rd.forward(request, response);
					}
					else
					{
						String msg="Sorry .Please check your Password.";
						request.setAttribute("ErrorMsgObj", msg);
						rd=request.getRequestDispatcher("Pages/Login.jsp");
						rd.forward(request, response);
					}
				}
				/*************EndSuccessPage************/
				
				
				
			}
			catch(Exception e)
			{
				String errMsg=e.getMessage();
				request.setAttribute("ErrorMsgObj", errMsg);
				RequestDispatcher rdError=request.getRequestDispatcher("ShowErrorPage");
				rdError.forward(request, response);
			}
		}
			else
			{
				response.getWriter().println("No Action is required");
			}

		}

	}
