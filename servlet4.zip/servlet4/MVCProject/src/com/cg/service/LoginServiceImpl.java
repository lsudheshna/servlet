package com.cg.service;

import java.sql.SQLException;

import com.cg.user.dao.*;
import com.cg.user.dto.*;
import com.cg.user.exception.LoginException;

public class LoginServiceImpl implements LoginService{
	LoginDaoImpl logDao=null;
	
	public LoginServiceImpl ()
	{
		super();
		logDao=new LoginDaoImpl();
	}
	
@Override
public Login getUserByUnm(String unm) throws LoginException
{
	try
	{
	return logDao.getUserByUnm(unm);
    }
	catch(Exception e)
	{
		throw new LoginException(e.getMessage());
	}
}
}
