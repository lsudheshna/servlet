package com.cg.web;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;


@WebServlet("/CartServlet")
public class CartServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
    
    public CartServlet() 
    {
        super();
        
    }

	
	public void init(ServletConfig config) throws ServletException 
	{
		
	}


	public void destroy() 
	{
	
	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response) 
			throws ServletException, IOException
	{
		doPost(request,response);
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException
	{
		PrintWriter out=response.getWriter();
		//selected book gets added in Array list which in turn is added in session
		String bname=request.getParameter("txtBook");
		HttpSession session=request.getSession(true);//to check some data in session or not
		ArrayList<String> bList=(ArrayList) session.getAttribute("BookListObj");//checks whether session contains booklistobj key or not		
		if(bList==null)
		{
			bList=new ArrayList<String>();
			bList.add(bname);
			session.setAttribute("BookListObj", bList);	//adding books to obj(key=value)		
		}
		else
		{
			bList.add(bname);
			session.setAttribute("BookListObj", bList);
		}
		out.println("<br/>Is this session new ?  "+ session.isNew());
		out.println("<br/>Session ID  " + session.getId());
		out.println("<br/>Max interval  " + session.getMaxInactiveInterval());
		out.println("<hr/>");
		out.println("<br/>Books in cart:  "+ bList);
		out.println("<br/>Do you want to purchase more");
		out.println("<br/><a href='/SessionProject/BookCatalogServlet'>Go to Home</a>");
	}
	
	
}
