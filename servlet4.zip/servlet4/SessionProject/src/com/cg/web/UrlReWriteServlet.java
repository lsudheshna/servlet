package com.cg.web;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


@WebServlet("/UrlReWriteServlet")
public class UrlReWriteServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
      
	int count=0;
    ServletConfig cg =null;
    public UrlReWriteServlet() {
        super();
        
    }

	
	public void init(ServletConfig config) throws ServletException {
		
		super.init(config);
		cg=config;
	}

	
	public void destroy() {
	
	}

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException 
	{
		doPost(request,response);
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException
	{
		String fid=request.getParameter("id");
		//String fname=request.getParameter("name");
		
		if(fid==null)
		{
			fid="1";
			count=Integer.parseInt(fid);
			count++;
		}
		else
		{
			count=Integer.parseInt(fid);
			count++;
		}
		PrintWriter pw=response.getWriter();
		pw.println("<b>u visited:"+count+"Times");
		pw.println("Do you want to visit again");
		pw.println("<a href='/SessionProject/UrlReWriteServlet?id="+count+" '>Click Here</a>");
	}
}
