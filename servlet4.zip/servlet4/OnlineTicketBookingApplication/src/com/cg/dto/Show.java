package com.cg.dto;

import java.time.LocalDate;

public class Show 
{
	private String sId;
	private String sName;
	private String sLocation;
	private LocalDate sDate;
	private int availSeats;
	private float sPrice;
	
	public Show() 
	{
		super();
	}
	
	public Show(String sId, String sName, String sLocation, LocalDate sDate,
			int availSeats, float sPrice)
	{
		super();
		this.sId = sId;
		this.sName = sName;
		this.sLocation = sLocation;
		this.sDate = sDate;
		this.availSeats = availSeats;
		this.sPrice = sPrice;
	}
	
	public String getsId() 
	{
		return sId;
	}
	public void setsId(String sId) 
	{
		this.sId = sId;
	}
	public String getsName()
	{
		return sName;
	}
	public void setsName(String sName) 
	{
		this.sName = sName;
	}
	public String getsLocation()
	{
		return sLocation;
	}
	public void setsLocation(String sLocation) 
	{
		this.sLocation = sLocation;
	}
	public LocalDate getsDate()
	{
		return sDate;
	}
	public void setsDate(LocalDate sDate)
	{
		this.sDate = sDate;
	}
	public int getAvailSeats() 
	{
		return availSeats;
	}
	public void setAvailSeats(int availSeats)
	{
		this.availSeats = availSeats;
	}
	public float getsPrice() 
	{
		return sPrice;
	}
	public void setsPrice(float sPrice)
	{
		this.sPrice = sPrice;
	}
	@Override
	public String toString()
	{
		return "Show [sId=" + sId + ", sName=" + sName + ", sLocation="
				+ sLocation + ", sDate=" + sDate + ", availSeats=" + availSeats
				+ ", sPrice=" + sPrice + "]";
	}
	
	
}
