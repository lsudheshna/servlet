package com.cg.dao;

public interface QueryMapper
{
	String selectQry="select * from ShowDetails ";
	String updateQry="update ShowDetails set AvSeats=? and ShowName=?";
	String selectQry2="select * from ShowDetails where ShowId=?"; 
}