package com.cg.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.cg.dto.Show;
import com.cg.exception.BookingException;
import com.cg.util.DBUtil;

public class IBookingDaoImpl implements BookingDao
{
	Connection con=null;
	Statement stmt=null;
	PreparedStatement pst=null;
	ResultSet rs=null;

	@Override
	public List<Show> getShowDetails() throws BookingException 
	{
		List<Show> showList=new ArrayList<Show>();
		Show show=null;
		con=DBUtil.getCon();
		try 
		{

			stmt=con.createStatement();
			rs=stmt.executeQuery(QueryMapper.selectQry);
			while(rs.next())
			{
				show=new Show();
				show.setsId(rs.getString("ShowId"));
				show.setsName(rs.getString("ShowName"));
				show.setsLocation(rs.getString("Location"));
				show.setsDate(rs.getDate("ShowDate").toLocalDate());
				show.setAvailSeats(rs.getInt("AvSeats"));
				show.setsPrice(rs.getFloat("PriceTicket"));
				showList.add(show);
			}

		}
		catch (Exception e)
		{

			throw new BookingException("Problem in fetching ShowDetails"+e.getMessage());

		} 
		finally
		{
			try
			{
				rs.close();
				stmt.close();
				con.close();
			} 
			catch (SQLException e)
			{
				throw new BookingException(e.getMessage());
			}

		}
		return showList;
	}

	@Override
	public int update(int seats,String showname)throws BookingException
	{
		int dataupdated=0;
		try 
		{
			con=DBUtil.getCon();
			pst=con.prepareStatement(QueryMapper.updateQry);
			pst.setInt(1, seats);
			pst.setString(2,showname);
			dataupdated=pst.executeUpdate();
		}
		catch (Exception e)
		{

			throw new BookingException("Problem in updating mobiles"+e.getMessage());

		} 
		return dataupdated;
	}

	@Override
	public List<Show> getShowDetailsById(String showid) throws BookingException
	{
		List<Show> showList=new ArrayList<Show>();
		Show show=null;
		con=DBUtil.getCon();
		try 
		{
			pst=con.prepareStatement(QueryMapper.selectQry2);
			pst.setString(1, showid);
			rs=pst.executeQuery();
			while(rs.next())
			{
				show=new Show();
				show.setsId(rs.getString("ShowId"));
				show.setsName(rs.getString("ShowName"));
				show.setsLocation(rs.getString("Location"));
				show.setsDate(rs.getDate("ShowDate").toLocalDate());
				show.setAvailSeats(rs.getInt("AvSeats"));
				show.setsPrice(rs.getFloat("PriceTicket"));
				showList.add(show);
			}

		}
		catch (Exception e)
		{

			throw new BookingException("Problem in fetching ShowDetails"+e.getMessage());

		} 
		finally
		{
			try
			{
				rs.close();
				pst.close();
				con.close();
			} 
			catch (SQLException e)
			{
				throw new BookingException(e.getMessage());
			}

		}
		return showList;
	}

}
