package com.cg.dao;

import java.util.List;

import com.cg.dto.Show;
import com.cg.exception.BookingException;

public interface BookingDao
{
	public List<Show> getShowDetails()throws BookingException;
	
	public int update(int seats,String showname)throws BookingException;
	
	public List<Show> getShowDetailsById(String showid)throws BookingException;
}
