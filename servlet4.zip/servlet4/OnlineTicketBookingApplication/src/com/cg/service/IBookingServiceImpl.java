package com.cg.service;

import java.util.List;

import com.cg.dao.BookingDao;
import com.cg.dao.IBookingDaoImpl;
import com.cg.dto.Show;
import com.cg.exception.BookingException;

public class IBookingServiceImpl implements BookingService
{
	BookingDao bDao=null;
	public IBookingServiceImpl() 
	{
		super();
		bDao=new IBookingDaoImpl();
	}

	@Override
	public List<Show> getShowDetails() throws BookingException 
	{
		return bDao.getShowDetails();
	}

	@Override
	public int update(int seats,String showname)throws BookingException
	{
	
		return bDao.update(seats, showname);
	}

	@Override
	public List<Show> getShowDetailsById(String showid) throws BookingException {
		
		return bDao.getShowDetailsById(showid);
	}
	
}
