package com.cg.BookingController;

import java.io.IOException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import com.cg.dto.Show;
import com.cg.exception.BookingException;
import com.cg.service.BookingService;
import com.cg.service.IBookingServiceImpl;


@WebServlet(urlPatterns={"/home","/Book","/Booking"})
public class BookingController extends HttpServlet 
{
	private static final long serialVersionUID = 1L;


	public BookingController() 
	{
		super();
	}


	public void init(ServletConfig config) throws ServletException
	{
	}


	public void destroy()
	{

	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException
	{
		doPost(request,response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) 
			throws ServletException, IOException 
	{
		String url=request.getServletPath();
		String targetUrl=" ";
		BookingService bSer=new IBookingServiceImpl();
		switch(url)
		{
		case "/home":

			try 
			{
				List<Show>showList=bSer.getShowDetails();
				request.setAttribute("showList", showList);
				targetUrl="showDetails.jsp";
			} 
			catch (BookingException e)
			{
				request.setAttribute("error", e.getMessage());
				targetUrl="Error.jsp";
			}
			break;	

		case "/Book":

			String sid=request.getParameter("showId");
			try 
			{
				List<Show>showList=bSer.getShowDetailsById(sid);
				request.setAttribute("showListObj", showList);
				targetUrl="bookNow.jsp";
			} 
			catch (BookingException e)
			{
				request.setAttribute("error", e.getMessage());
				targetUrl="Error.jsp";
			}
			break;

		case "/Booking":

			String name=request.getParameter("showname");
			float price=Float.parseFloat(request.getParameter("tprice"));
			String customername=request.getParameter("custname");
			String phoneno=request.getParameter("phoneno");
			int availability=Integer.parseInt(request.getParameter("avseats"));
			int book=Integer.parseInt(request.getParameter("bseats"));

			if(book>0)
			{
					float totalprice=book*price;
					HttpSession session=request.getSession(true);
					session.setAttribute("nameobj",name);
					session.setAttribute("cnameobj",customername);
					session.setAttribute("phnobj",phoneno);
					session.setAttribute("bobj",book);
					session.setAttribute("tobj",totalprice);
					targetUrl="Success.jsp";
			}
			
			break;
		}
		RequestDispatcher rd=request.getRequestDispatcher(targetUrl);
		rd.forward(request, response);
	}

}
