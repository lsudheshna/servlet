package com.cg.emp.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.cg.emp.dto.EmployeeDetails;
import com.cg.emp.dto.EmployeeLeaveDetails;
import com.cg.emp.service.IEmployeeService;



@Controller
public class employeeController 
{
	@Autowired
	IEmployeeService employeeservice;
	
	@RequestMapping(value="showAll",method=RequestMethod.GET)
	public String getAll()
	{
		/*Redirects to 'Home.jsp' page*/
		return "Home";
	}
	
	/*The request with value 'search' is caught here*/
	@RequestMapping(value="search", method=RequestMethod.GET)
	public ModelAndView search(@RequestParam("id") long sid)
	{
		ModelAndView mv=new ModelAndView();
		
		/*checks whether the given Employee ID is valid or not*/
		if(employeeservice.validateId(sid))
		{
			List<EmployeeLeaveDetails> searched=employeeservice.showLeaveHistory(sid);
			EmployeeDetails e=employeeservice.showEmployeeById(sid);
			
			/*Opens the view of 'viewLeaveDetails'*/
			mv.setViewName("ViewLeaveDetails");
			mv.addObject("temp1", searched);
			mv.addObject("temp", e);
			
			return mv;
			
		}
		/*Returns to home page if Employee ID is not valid */
		return new ModelAndView("Home", "error","This Employee ID Doesnot exist...");
	}
	
	
}
