package com.cg.emp.service;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.emp.dao.IEmployeeDao;
import com.cg.emp.dto.EmployeeDetails;
import com.cg.emp.dto.EmployeeLeaveDetails;

@Service("employeeservice")
@Transactional
public class EmployeeServiceImpl implements IEmployeeService
{
	@Autowired
	IEmployeeDao employeedao;
	@Override
	public EmployeeDetails showEmployeeById(long empId)
	{
		
		return employeedao.showEmployeeById(empId);
	}

	@Override
	public List<EmployeeLeaveDetails> showLeaveHistory(long empId) 
	{
		
		return employeedao.showLeaveHistory(empId);
	}

	@Override
	public List<Long> showEmployeeIds() 
	{
		
		return employeedao.showEmployeeIds();
	}
	
	@Override
	public boolean validateId(long empId)
	{
		List<Long> getIds=employeedao.showEmployeeIds();
		for(Long i:getIds)
		{
			if(i==empId)
				return true;
		}
		return false;
	} 
}
