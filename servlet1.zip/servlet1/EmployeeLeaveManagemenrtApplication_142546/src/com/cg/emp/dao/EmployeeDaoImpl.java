package com.cg.emp.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;

import com.cg.emp.dto.EmployeeDetails;
import com.cg.emp.dto.EmployeeLeaveDetails;

@Repository("employeedao")
public class EmployeeDaoImpl implements IEmployeeDao
{
	@PersistenceContext
	EntityManager entitymanager;
	
	@Override
	public EmployeeDetails showEmployeeById(long empId) 
	{
		EmployeeDetails Id=entitymanager.find(EmployeeDetails.class,empId);
		return Id;
	}

	@Override
	public List<EmployeeLeaveDetails> showLeaveHistory(long empId) 
	{
		//Query q2 = entitymanager.createQuery("SELECT emp.empStartDate,emp.empEndDate,emp.empDescription,emp.empLeaves FROM EmployeeLeaveDetails emp WHERE empId=:eid");
		Query q2 = entitymanager.createQuery("FROM EmployeeLeaveDetails where empId=:eid");
		q2.setParameter("eid", empId);
		List<EmployeeLeaveDetails> myList = q2.getResultList();
		return myList;
	}

	@Override
	public List<Long> showEmployeeIds() 
	{
		Query query1=entitymanager.createQuery("SELECT employee.empId FROM EmployeeDetails employee");
		return query1.getResultList();
	}

}
