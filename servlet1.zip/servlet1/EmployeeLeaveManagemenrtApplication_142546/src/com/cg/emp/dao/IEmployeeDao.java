package com.cg.emp.dao;

import java.util.List;

import com.cg.emp.dto.EmployeeDetails;
import com.cg.emp.dto.EmployeeLeaveDetails;

public interface IEmployeeDao 
{
	EmployeeDetails showEmployeeById(long empId);
	List<EmployeeLeaveDetails> showLeaveHistory(long empId);
	List<Long> showEmployeeIds();
}
