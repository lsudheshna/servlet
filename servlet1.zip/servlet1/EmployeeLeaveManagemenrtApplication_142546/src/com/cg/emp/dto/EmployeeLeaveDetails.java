package com.cg.emp.dto;

import java.time.LocalDate;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="employee_leave_details")
public class EmployeeLeaveDetails 
{
	@Id
	@Column(name="leave_id")
	private int empLeaveId;
	
	@Column(name="empid")
	private long empId;
	
	@Column(name="start_date")
	String empStartDate;
	
	@Column(name="end_date")
	String empEndDate;
	
	@Column(name="description")
	private String empDescription;
	
	@Column(name="leaves_applied")
	private int empLeaves;

	public int getEmpLeaveId() 
	{
		return empLeaveId;
	}

	public void setEmpLeaveId(int empLeaveId)
	{
		this.empLeaveId = empLeaveId;
	}

	public long getEmpId()
	{
		return empId;
	}

	public void setEmpId(long empId)
	{
		this.empId = empId;
	}

	public String getEmpStartDate()
	{
		return empStartDate;
	}

	public void setEmpStartDate(String empStartDate) 
	{
		this.empStartDate = empStartDate;
	}

	public String getEmpEndDate() 
	{
		return empEndDate;	
	}

	public void setEmpEndDate(String empEndDate)
	{
		this.empEndDate = empEndDate;
	}

	public String getEmpDescription() 
	{
		return empDescription;
	}

	public void setEmpDescription(String empDescription)
	{
		this.empDescription = empDescription;
	}

	public int getEmpLeaves() 
	{
		return empLeaves;
	}

	public void setEmpLeaves(int empLeaves)
	{
		this.empLeaves = empLeaves;
	}
	
	
}
