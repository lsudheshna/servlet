package com.cg.emp.dto;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="employee_details")
public class EmployeeDetails 
{
	@Id
	@Column(name="empid")
	private long empId;
	
	@Column(name="ename")
	private String empName;
	
	@Column(name="address")
	private String empAddress;
	
	@Column(name="leaves_avail")
	private int empAvailLeaves;
	
	
	public long getEmpId() 
	{
		return empId;
	}
	public void setEmpId(long empId) 
	{
		this.empId = empId;
	}
	public String getEmpName()
	{
		return empName;
	}
	public void setEmpName(String empName) 
	{
		this.empName = empName;
	}
	public String getEmpAddress()
	{
		return empAddress;
	}
	public void setEmpAddress(String empAddress)
	{
		this.empAddress = empAddress;
	}
	public int getEmpAvailLeaves() 
	{
		return empAvailLeaves;
	}
	public void setEmpAvailLeaves(int empAvailLeaves)
	{
		this.empAvailLeaves = empAvailLeaves;
	}
	
	
	
}
