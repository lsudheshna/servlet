package com.cg.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import com.cg.dto.Bill;
import com.cg.dto.Consumer;
import com.cg.exception.BillException;
import com.cg.util.DBUtil;

public class IBillDaoImpl implements BillDao
{
	Connection con=null;
	Statement st=null;
	PreparedStatement pst=null;
	ResultSet rs=null;

	@Override
	public ArrayList<Consumer> getConsumerDetails() throws BillException
	{
		ArrayList<Consumer> cList=new ArrayList<Consumer>();
		Consumer c=null;
		try 
		{
			con=DBUtil.getCon();
			st=con.createStatement();
			rs=st.executeQuery("select consumer_num,consumer_name,address from Consumers");
			while(rs.next())
			{
				c=new Consumer();
				c.setConsumernum(rs.getLong("consumer_num"));
				c.setConsumername(rs.getString("consumer_name"));
				c.setAddress(rs.getString("address"));
				cList.add(c);
			}

		} 
		catch (SQLException e)
		{
			throw new BillException("Error in fetching Consumer details"+e.getMessage());				
		}

		return cList;
	}

	@Override
	public Consumer searchConsumer(long cnum) throws BillException
	{
		Consumer c=null;
		try
		{
			con=DBUtil.getCon();
			pst=con.prepareStatement("select consumer_num,consumer_name,address from Consumers where consumer_num=?");
			pst.setLong(1, cnum);
			rs=pst.executeQuery();
			if(rs.next())
			{
				c=new Consumer();
				c.setConsumernum(rs.getLong("consumer_num"));
				c.setConsumername(rs.getString("consumer_name"));
				c.setAddress(rs.getString("address"));
			}
		}
		catch (SQLException e)
		{
			throw new BillException("Error in fetching Consumer details"+e.getMessage());				
		}
		return c;
	}

	public ArrayList<Bill> getBillDetails(long cnum) throws BillException
	{
		ArrayList<Bill> bList=new ArrayList<Bill>();
		Bill b=null;
		try 
		{
			con=DBUtil.getCon();
			pst=con.prepareStatement("select bill_num,cur_reading,unitConsumed,netAmount, from Bill where consumer_num=?");
			pst.setLong(1,cnum);
			while(rs.next())
			{
				b=new Bill();
				b.setBillNum(rs.getInt("bill_num"));
				b.setCurrentReading(rs.getLong("currentReading"));
				b.setUnitsConsumed(rs.getLong("unitsConsumed"));
				b.setBilldate(rs.getDate("bill_date"));
				bList.add(b);
			}

		} 
		catch (SQLException e)
		{
			throw new BillException("Error in fetching bill details"+e.getMessage());				
		}

		return bList;
	}
}
