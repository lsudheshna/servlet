package com.cg.ctrl;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.cg.dto.Bill;
import com.cg.dto.Consumer;
import com.cg.exception.BillException;
import com.cg.service.BillService;
import com.cg.service.IBillServiceImpl;

@WebServlet(urlPatterns={"/BillController","/Search","/SearchOne"})
public class BillController extends HttpServlet 
{
	private static final long serialVersionUID = 1L;
	BillService bSer=null; 

	public BillController()
	{
		super();

	}

	public void init(ServletConfig config) throws ServletException 
	{

	}

	public void destroy()
	{

	}


	protected void doGet(HttpServletRequest request, HttpServletResponse response) 
			throws ServletException, IOException
	{
		doPost(request,response);
	}


	protected void doPost(HttpServletRequest request, HttpServletResponse response) 
			throws ServletException, IOException
	{
		String Url=request.getServletPath();
		String targeturl=" ";
		bSer=new IBillServiceImpl();

		switch(Url)
		{
		case "/BillController":

			try 
			{
				ArrayList <Consumer> cList=bSer.getConsumerDetails();
				request.setAttribute("cList", cList);
				targeturl="Show_ConsumerList.jsp";
			} 
			catch (BillException e) 
			{
				request.setAttribute("error",e.getMessage());
				targeturl="Error.jsp";
			}

			break;

		case "/Search":
			
			targeturl="SearchConsumer.jsp";
			break;
		
		case "/SearchOne":

			Long cnumber=Long.parseLong(request.getParameter("conid"));
			try
			{
				Consumer consumer=bSer.searchConsumer(cnumber);
				HttpSession session=request.getSession(true);
				session.setAttribute("consumer", consumer);
				targeturl="ShowConsumer.jsp";	
			} 
			catch (BillException e) 
			{
				request.setAttribute("Error", e.getMessage());
				targeturl="Error.jsp";
			}
			break;
			
			
		case "/show":
			
			Long cno=Long.parseLong(request.getParameter("conid"));
			try
			{
			ArrayList <Bill> bList=bSer.getBillDetails(cno);
			HttpSession session=request.getSession(true);
			session.setAttribute("bList", bList);
			targeturl="ShowBillDetails.jsp";
			}
			catch (BillException e) 
			{
				request.setAttribute("Error", e.getMessage());
				targeturl="Error.jsp";
			}
		
			break;
		}
		RequestDispatcher rd=request.getRequestDispatcher(targeturl);
		rd.forward(request, response);

	}	

}





