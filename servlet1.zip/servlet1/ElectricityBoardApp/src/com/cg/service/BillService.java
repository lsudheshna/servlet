package com.cg.service;

import java.util.ArrayList;

import com.cg.dto.Bill;
import com.cg.dto.Consumer;
import com.cg.exception.BillException;

public interface BillService 
{
ArrayList<Consumer> getConsumerDetails() throws BillException;
	
	Consumer searchConsumer(long cnum)throws BillException;
	public ArrayList<Bill> getBillDetails(long cnum)throws BillException;
}
