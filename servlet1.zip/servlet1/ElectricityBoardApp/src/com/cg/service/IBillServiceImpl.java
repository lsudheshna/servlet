package com.cg.service;

import java.util.ArrayList;

import com.cg.dao.BillDao;
import com.cg.dao.IBillDaoImpl;
import com.cg.dto.Bill;
import com.cg.dto.Consumer;
import com.cg.exception.BillException;

public class IBillServiceImpl implements BillService
{
	BillDao bDao=null;
	
	public IBillServiceImpl()
	{
		super();
		bDao=new IBillDaoImpl();
	}

	@Override
	public ArrayList<Consumer> getConsumerDetails() throws BillException 
	{
		return bDao.getConsumerDetails();
	}

	@Override
	public Consumer searchConsumer(long cnum) throws BillException
	{
		return bDao.searchConsumer(cnum);
	}

	@Override
	public ArrayList<Bill> getBillDetails(long cnum) throws BillException {

		return bDao.getBillDetails(cnum);
	}
	
}
