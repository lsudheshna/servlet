package com.cg.dao;

import com.cg.dto.Bill;
import com.cg.exception.BillException;

public interface eBillDao
{
	public String getCustomerName(long consumernum) throws BillException;
	
	public int BillCalc(Bill b)throws BillException;
	
	public int generatebillnum() throws BillException; 
}
