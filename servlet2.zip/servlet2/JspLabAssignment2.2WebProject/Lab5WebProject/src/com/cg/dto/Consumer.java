package com.cg.dto;

public class Consumer 
{
	private long consumernum;
	private String consumername;
	private String address;
	
	
	public Consumer() 
	{
		super();
		// TODO Auto-generated constructor stub
	}


	public Consumer(long consumer_num, String consumer_name, String address)
	{
		super();
		this.consumernum = consumer_num;
		this.consumername = consumer_name;
		this.address = address;
	}


	public long getConsumernum() 
	{
		return consumernum;
	}


	public void setConsumernum(long consumernum)
	{
		this.consumernum = consumernum;
	}


	public String getConsumername() 
	{
		return consumername;
	}


	public void setConsumername(String consumername)
	{
		this.consumername = consumername;
	}


	public String getAddress() {
		return address;
	}


	public void setAddress(String address)
	{
		this.address = address;
	}


	@Override
	public String toString() 
	{
		return "Consumer [consumernum=" + consumernum + ", consumername="
				+ consumername + ", address=" + address + "]";
	}
	
	
	
}
