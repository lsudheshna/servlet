package com.cg.service;

import java.util.ArrayList;

import com.cg.dao.*;
import com.cg.dto.Bill;
import com.cg.dto.Consumer;
import com.cg.exception.BillException;

public class eBillServiceImpl implements eBillService
{
	eBillDao eDao=null;
	
	public eBillServiceImpl() 
	{
		super();
		eDao=new eBillDaoImpl();
	}

	@Override
	public String getCustomerName(long consumernum) throws BillException
	{
		try
		{
		return eDao.getCustomerName(consumernum);
		}
		catch(Exception e)
		{
			throw new BillException(e.getMessage());
		}
	}

	@Override
	public int BillCalc(Bill b) throws BillException
	{
		try
		{
		return eDao.BillCalc(b);
		}
		catch(Exception e)
		{
			throw new BillException(e.getMessage());
		}
	}
	
	public int generatebillnum() throws BillException 
	{
		try
		{
		return eDao.generatebillnum();
		}
		catch(Exception e)
		{
			throw new BillException(e.getMessage());
		}
	}
}
