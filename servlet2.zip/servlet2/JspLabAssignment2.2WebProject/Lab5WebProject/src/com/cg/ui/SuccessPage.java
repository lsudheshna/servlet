package com.cg.ui;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import com.cg.exception.BillException;
import com.cg.service.eBillService;
import com.cg.service.eBillServiceImpl;


@WebServlet("/SuccessPage")
public class SuccessPage extends HttpServlet
{
	private static final long serialVersionUID = 1L;
	ServletConfig cg=null;
	eBillService eSer=null;

	
	public SuccessPage() 
	{
		super();

	}


	public void init(ServletConfig config) throws ServletException
	{
		super.init(config);
		cg=config;
	}

	public void destroy()
	{

	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response) 
			throws ServletException, IOException 
	{
		doPost(request,response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) 
			throws ServletException, IOException ,NumberFormatException
	{

		HttpSession session=request.getSession(true);
		PrintWriter out=response.getWriter();
		eSer=new eBillServiceImpl();
		String cname;
		
		try
		{
			
			float unit=(float) session.getAttribute("unitsObj");
			float total=(float) session.getAttribute("totalObj");
			Long id=(Long) session.getAttribute("numObj");
			
			System.out.println(id);
			System.out.println(total);
			cname = eSer.getCustomerName(id);
			out.println("<h1>Welcome"+cname+"</h1>");
			out.print("<h2>Electricity Bill for Consumer Number-"+id+ "</h2>is  ");
			out.println("<h2> Units Consumed::</h2><br>"+unit);
			out.println("<h2> Net Amount::</h2><br>"+total);
		}
		
		catch (BillException e) 
		{
			String errMsg=e.getMessage();
			request.setAttribute("ErrorMsgObj", errMsg);
			RequestDispatcher rdError=request.getRequestDispatcher("ShowErrorPage");
			rdError.forward(request, response);
		}
	}

}
