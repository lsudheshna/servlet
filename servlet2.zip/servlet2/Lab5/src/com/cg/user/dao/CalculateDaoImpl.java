package com.cg.user.dao;

import java.sql.*;
import java.util.ArrayList;

import com.cg.user.dto.Bill;
import com.cg.user.exception.BillException;
import com.cg.user.util.DBUtil;

public class CalculateDaoImpl implements ICalculateDao
{
	Connection con=null;
	Statement st=null;
	PreparedStatement pst=null;
	ResultSet rs=null;
	@Override
	public int addBillDetails(Bill bill) throws BillException 
	{
		String insertQry="insert into billdetails(bill_num,consumer_num,cur_reading,"
				+ "unitConsumed,netAmount) values(?,?,?,?,?)";
		int dataAdded=0;
		try
		{
			con=DBUtil.getCon();
			pst=con.prepareStatement(insertQry);
			pst.setInt(1, genetateBillNum());
			pst.setLong(2, bill.getConsumerNo());
			pst.setFloat(3, bill.getCurrentReading());
			pst.setFloat(4, bill.getUnitsConsumed());
			pst.setFloat(5, bill.getNetAmount());
			dataAdded=pst.executeUpdate();
		} 
		catch (SQLException e)
		{
			throw new BillException(e.getMessage());
		}
		return dataAdded;
	}
	public  int genetateBillNum() throws BillException 
	{
		String qry="Select seq_bill_num.NEXTVAL from dual";
		int generatedVal=0;
		try 
		{
			con=DBUtil.getCon();
			st=con.createStatement();
			rs=st.executeQuery(qry);
			rs.next();
			generatedVal=rs.getInt(1);
		} 
		catch (Exception e) 
		{
			throw new BillException(e.getMessage());
		}
		finally
		{
			try 
			{
				rs.close();
				st.close();
				con.close();
			}
			catch (SQLException e) 
			{
				throw new BillException(e.getMessage());
			}
		}
		return generatedVal;
	}
	@Override
	public ArrayList<Long> getCustomerId() throws BillException {
		String selectQry="SELECT consumer_num FROM consumers";
		ArrayList<Long> conList=new ArrayList<Long>();
		Long conId;
		try 
		{
			con=DBUtil.getCon();
			st=con.createStatement();
			rs=st.executeQuery(selectQry);
			while(rs.next())
			{
				conId=rs.getLong(1);
				conList.add(conId);
			}
		} 
		catch (Exception e) 
		{
			throw new BillException(e.getMessage());
		}
		finally
		{
			try 
			{
				
				st.close();
				con.close();
			}
			catch (SQLException e) 
			{
				throw new BillException(e.getMessage());
			}
		}
		return conList;
		
	}
	@Override
	public String getCustomerName(Long consumerNo) throws BillException {
		String selectQry="SELECT consumer_name FROM consumers where consumer_num=?";
		String cname=null;
		try 
		{
			con=DBUtil.getCon();
			pst=con.prepareStatement(selectQry);
			pst.setLong(1, consumerNo);
			rs=pst.executeQuery();
			rs.next();
			cname=rs.getString(1);
		} 
		catch (Exception e) 
		{
			throw new BillException(e.getMessage());
		}
		finally
		{
			try 
			{
				pst.close();
				con.close();
			} 
			catch (SQLException e) 
			{
				
				throw new BillException(e.getMessage());
			}	
		}
		return cname;
	}
}