package com.cg.ui;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.cg.dto.EmployeeBean;
import com.cg.dto.EmployeeDetail;

public class EmployeeTest
{

	public static void main(String[] args)
	{
		ApplicationContext app=new ClassPathXmlApplicationContext("spring.xml");
		EmployeeDetail e=(EmployeeBean) app.getBean("emp");//from xml through constructor Injection
		e.getAllEmpDetail();

	}

}
