package com.cg.dto;

public class EmployeeBean implements EmployeeDetail
{
	int employeeId;
	String employeeName;
	double salary;
	SBUBean sbean;

	public EmployeeBean() 
	{
		super();
		// TODO Auto-generated constructor stub
	}

	public SBUBean getSbean() {
		return sbean;
	}

	public void setSbean(SBUBean sbean) {
		this.sbean = sbean;
	}

	public EmployeeBean(int employeeId, String employeeName, double salary) {
		super();
		this.employeeId = employeeId;
		this.employeeName = employeeName;
		this.salary = salary;
	}


	public int getEmployeeId() {
		return employeeId;
	}


	public void setEmployeeId(int employeeId) {
		this.employeeId = employeeId;
	}


	public String getEmployeeName() {
		return employeeName;
	}


	public void setEmployeeName(String employeeName) {
		this.employeeName = employeeName;
	}


	public double getSalary() {
		return salary;
	}


	public void setSalary(double salary) {
		this.salary = salary;
	}


	public void getAllEmpDetail()
	{
		System.out.println("EmployeeBean [employeeId=" + employeeId + ", employeeName="
				+ employeeName + ", salary=" + salary + ", sbean=" + sbean
				+ "]");

		System.out.println("SBUBean [SbuId=" + sbean.getSbuId() + ", SbuName=" + sbean.getSbuName()
					+ ", SbuHead=" + sbean.getSbuHead() + "]");
		}
	}


