package com.cg.dto;

public class SBUBean
{
	private int SbuId;
	private String SbuName;
	private String SbuHead;
	
	public SBUBean()
	{
		super();
		// TODO Auto-generated constructor stub
	}

	public int getSbuId() {
		return SbuId;
	}

	public void setSbuId(int sbuId) {
		SbuId = sbuId;
	}

	

	public String getSbuName() {
		return SbuName;
	}

	public void setSbuName(String sbuName) {
		SbuName = sbuName;
	}

	public String getSbuHead() {
		return SbuHead;
	}

	public void setSbuHead(String sbuHead) {
		SbuHead = sbuHead;
	}
	
	
}
