package com.cg.web;

import java.io.IOException;
import java.sql.SQLException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cg.dto.Registration;
import com.cg.service.RegService;
import com.cg.service.RegServiceImpl;

@WebServlet("/RegistrationServlet")
public class RegistrationServlet extends HttpServlet
{
	RegServiceImpl reSer=null;
	int dataadded=0;
	private static final long serialVersionUID = 1L;
       
   
    public RegistrationServlet() {
        super();
       
    }

	
	public void init(ServletConfig config) throws ServletException {
		
	}

	public void destroy() {
	
	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		doPost(request,response);
	}


	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		
		reSer=new RegServiceImpl();
		
		String fnm=request.getParameter("fname");
		String lnm=request.getParameter("lname");
		String pwd=request.getParameter("pawd");
		String gen=request.getParameter("gender");
		String loc=request.getParameter("city");
		String[] dom=request.getParameterValues("skill");
		String concat=null;
		
		int length=dom.length;
		concat=dom[0];
		if(length==1)
		{
			concat=dom[0];
		}
		else
		{
		for(int i=1;i<length;i++)
		{
			concat+=dom[i];
		}
		}
		
		Registration reg=new Registration(fnm,lnm,pwd,gen,concat,loc);
		
		reg.setFname(fnm);
		reg.setLname(lnm);
		reg.setPassword(pwd);
		reg.setGender(gen);
		reg.setCity(loc);
		reg.setSkill(concat);
		
		
		try 
		{
			dataadded = reSer.getUser(reg);
			if(dataadded==1)
			{
				response.sendRedirect("/Lab3.2WebProject/success.html");
			}
			else
			{
				response.sendRedirect("/Lab3.2WebProject/failure.html");
			}
		} 
		
		catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
	}

}
