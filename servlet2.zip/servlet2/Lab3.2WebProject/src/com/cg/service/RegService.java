package com.cg.service;

import java.sql.SQLException;

import com.cg.dto.Registration;

public interface RegService
{
	public int getUser(Registration reg) throws SQLException;
}
